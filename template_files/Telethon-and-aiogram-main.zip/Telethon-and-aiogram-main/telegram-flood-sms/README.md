## **Telegram sms flooder**
Telegram telefon raqamiga telegram tomonidan 1 marotabalik code yuboradi hamda notogri parolni kiritadi va buni takrorlaydi, toki telefon raqami flood olmaguncha yani flood bu keyingi marotaba telefon raqami orqali tgga kirmoqchi bo'lsa kira olmaydi 24 soat kut deyaveradi
## **O'rnatish**
termux dasturiga kirasiz 
apt update
apt upgrade 
pkg install python
pip install telethon
----
endi 1s.py fileni edit qilasiz 
![image](https://github.com/user-attachments/assets/d5d4b3eb-ccc8-48c0-a163-fff81932e19e)
mana shu joyga tel raqam yozing agar 2-3 ta tel raqam bolsa unda vergul bilan yozing misol uchun: +998900000000, +998901111111 

## **Dasturchi**

Telegram Kanal: **[Satomoru](https://t.me/satomoru_official)**

Muloqot uchun: **[Hevorix](https://t.me/hevorix)**

Youtube Kanal: **[X.SATOMORU](https://youtube.com/@DARKNET_OFF1CIAL)**
